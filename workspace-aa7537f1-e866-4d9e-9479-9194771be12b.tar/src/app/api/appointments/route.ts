import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all appointments
export async function GET() {
  try {
    const appointments = await db.appointment.findMany({
      include: {
        patient: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        doctor: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        user: {
          select: {
            name: true,
            email: true
          }
        }
      },
      orderBy: {
        date: 'desc'
      }
    })

    return NextResponse.json(appointments)
  } catch (error) {
    console.error('Error fetching appointments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch appointments' },
      { status: 500 }
    )
  }
}

// POST new appointment
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    const appointment = await db.appointment.create({
      data: {
        patientId: data.patientId,
        doctorId: data.doctorId,
        userId: data.userId,
        date: new Date(data.date),
        time: data.time,
        reason: data.reason,
        notes: data.notes
      },
      include: {
        patient: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        doctor: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        }
      }
    })

    return NextResponse.json(appointment, { status: 201 })
  } catch (error) {
    console.error('Error creating appointment:', error)
    return NextResponse.json(
      { error: 'Failed to create appointment' },
      { status: 500 }
    )
  }
}