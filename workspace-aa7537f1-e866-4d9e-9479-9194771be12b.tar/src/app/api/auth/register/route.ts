import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

// POST quick registration
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    // Validate required fields
    if (!data.name || !data.email || !data.phone || !data.role) {
      return NextResponse.json(
        { error: 'Missing required fields: name, email, phone, role' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email: data.email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(data.password || 'temp123', 10)

    // Create user
    const user = await db.user.create({
      data: {
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: data.role,
        password: hashedPassword
      },
      include: {
        patient: true,
        doctor: true,
        staff: true
      }
    })

    // Create role-specific profile
    let profile = null
    if (data.role === 'PATIENT') {
      profile = await db.patient.create({
        data: {
          userId: user.id,
          bloodGroup: data.bloodGroup,
          allergies: data.allergies,
          medicalHistory: data.medicalHistory,
          emergencyContact: data.emergencyContact,
          dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth) : null,
          gender: data.gender,
          address: data.address
        }
      })
    } else if (data.role === 'DOCTOR') {
      profile = await db.doctor.create({
        data: {
          userId: user.id,
          specialization: data.specialization || 'General Medicine',
          qualification: data.qualification || 'MBBS',
          experience: data.experience ? parseInt(data.experience) : null,
          consultationFee: data.consultationFee ? parseFloat(data.consultationFee) : 100,
          availableDays: JSON.stringify(data.availableDays || ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']),
          availableTime: JSON.stringify(data.availableTime || ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM'])
        }
      })
    } else if (data.role === 'NURSE' || data.role === 'RECEPTIONIST' || data.role === 'PHARMACIST' || data.role === 'LAB_TECHNICIAN') {
      profile = await db.staff.create({
        data: {
          userId: user.id,
          department: data.department || 'General',
          position: data.position || data.role,
          salary: data.salary ? parseFloat(data.salary) : null
        }
      })
    }

    // Generate JWT token for auto-login
    const token = jwt.sign(
      { 
        userId: user.id,
        email: user.email,
        role: user.role 
      },
      process.env.JWT_SECRET || 'fallback-secret-key',
      { expiresIn: '7d' }
    )

    // Return user data without password
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      message: 'Registration successful',
      token,
      user: userWithoutPassword,
      profile
    }, { status: 201 })

  } catch (error) {
    console.error('Error in quick registration:', error)
    return NextResponse.json(
      { error: 'Failed to register user' },
      { status: 500 }
    )
  }
}