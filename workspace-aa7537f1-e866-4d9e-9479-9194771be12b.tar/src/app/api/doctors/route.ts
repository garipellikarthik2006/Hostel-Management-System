import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all doctors
export async function GET() {
  try {
    const doctors = await db.doctor.findMany({
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            createdAt: true
          }
        },
        _count: {
          select: {
            appointments: true,
            medicalRecords: true,
            prescriptions: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(doctors)
  } catch (error) {
    console.error('Error fetching doctors:', error)
    return NextResponse.json(
      { error: 'Failed to fetch doctors' },
      { status: 500 }
    )
  }
}

// POST new doctor
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    // Create user first
    const user = await db.user.create({
      data: {
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: 'DOCTOR',
        password: data.password || 'temp123' // In production, hash this password
      }
    })

    // Create doctor profile
    const doctor = await db.doctor.create({
      data: {
        userId: user.id,
        specialization: data.specialization,
        qualification: data.qualification,
        experience: data.experience ? parseInt(data.experience) : null,
        consultationFee: parseFloat(data.consultationFee),
        availableDays: JSON.stringify(data.availableDays || []),
        availableTime: JSON.stringify(data.availableTime || [])
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            createdAt: true
          }
        }
      }
    })

    return NextResponse.json(doctor, { status: 201 })
  } catch (error) {
    console.error('Error creating doctor:', error)
    return NextResponse.json(
      { error: 'Failed to create doctor' },
      { status: 500 }
    )
  }
}