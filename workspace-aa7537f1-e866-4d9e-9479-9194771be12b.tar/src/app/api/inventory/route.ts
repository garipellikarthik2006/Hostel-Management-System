import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET inventory logs
export async function GET() {
  try {
    const inventoryLogs = await db.inventoryLog.findMany({
      include: {
        medicine: {
          select: {
            name: true,
            category: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(inventoryLogs)
  } catch (error) {
    console.error('Error fetching inventory logs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch inventory logs' },
      { status: 500 }
    )
  }
}

// POST inventory adjustment
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    // Create inventory log
    const inventoryLog = await db.inventoryLog.create({
      data: {
        medicineId: data.medicineId,
        type: data.type, // 'IN' for stock addition, 'OUT' for stock reduction
        quantity: parseInt(data.quantity),
        reason: data.reason
      },
      include: {
        medicine: true
      }
    })

    // Update medicine stock
    const currentMedicine = await db.medicine.findUnique({
      where: { id: data.medicineId }
    })

    if (currentMedicine) {
      const stockChange = data.type === 'IN' ? parseInt(data.quantity) : -parseInt(data.quantity)
      const newStock = Math.max(0, currentMedicine.stock + stockChange)
      
      await db.medicine.update({
        where: { id: data.medicineId },
        data: { stock: newStock }
      })
    }

    return NextResponse.json(inventoryLog, { status: 201 })
  } catch (error) {
    console.error('Error creating inventory log:', error)
    return NextResponse.json(
      { error: 'Failed to create inventory log' },
      { status: 500 }
    )
  }
}