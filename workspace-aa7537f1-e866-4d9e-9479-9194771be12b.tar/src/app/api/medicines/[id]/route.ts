import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET single medicine
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const medicine = await db.medicine.findUnique({
      where: { id: params.id },
      include: {
        billItems: {
          include: {
            bill: {
              include: {
                patient: {
                  include: {
                    user: {
                      select: {
                        name: true
                      }
                    }
                  }
                }
              }
            }
          },
          orderBy: {
            createdAt: 'desc'
          }
        },
        inventoryLogs: {
          orderBy: {
            createdAt: 'desc'
          }
        },
        _count: {
          select: {
            billItems: true,
            inventoryLogs: true
          }
        }
      }
    })

    if (!medicine) {
      return NextResponse.json(
        { error: 'Medicine not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(medicine)
  } catch (error) {
    console.error('Error fetching medicine:', error)
    return NextResponse.json(
      { error: 'Failed to fetch medicine' },
      { status: 500 }
    )
  }
}

// PUT update medicine
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json()
    
    const medicine = await db.medicine.update({
      where: { id: params.id },
      data: {
        name: data.name,
        description: data.description,
        category: data.category,
        price: data.price ? parseFloat(data.price) : undefined,
        stock: data.stock !== undefined ? parseInt(data.stock) : undefined,
        minStock: data.minStock ? parseInt(data.minStock) : undefined,
        expiryDate: data.expiryDate ? new Date(data.expiryDate) : undefined,
        manufacturer: data.manufacturer
      }
    })

    return NextResponse.json(medicine)
  } catch (error) {
    console.error('Error updating medicine:', error)
    return NextResponse.json(
      { error: 'Failed to update medicine' },
      { status: 500 }
    )
  }
}

// DELETE medicine
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.medicine.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Medicine deleted successfully' })
  } catch (error) {
    console.error('Error deleting medicine:', error)
    return NextResponse.json(
      { error: 'Failed to delete medicine' },
      { status: 500 }
    )
  }
}