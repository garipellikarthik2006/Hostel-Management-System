import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all medicines
export async function GET() {
  try {
    const medicines = await db.medicine.findMany({
      include: {
        _count: {
          select: {
            billItems: true,
            inventoryLogs: true
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json(medicines)
  } catch (error) {
    console.error('Error fetching medicines:', error)
    return NextResponse.json(
      { error: 'Failed to fetch medicines' },
      { status: 500 }
    )
  }
}

// POST new medicine
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    const medicine = await db.medicine.create({
      data: {
        name: data.name,
        description: data.description,
        category: data.category,
        price: parseFloat(data.price),
        stock: parseInt(data.stock),
        minStock: parseInt(data.minStock) || 10,
        expiryDate: data.expiryDate ? new Date(data.expiryDate) : null,
        manufacturer: data.manufacturer
      }
    })

    // Create initial inventory log
    await db.inventoryLog.create({
      data: {
        medicineId: medicine.id,
        type: 'IN',
        quantity: parseInt(data.stock),
        reason: 'Initial stock'
      }
    })

    return NextResponse.json(medicine, { status: 201 })
  } catch (error) {
    console.error('Error creating medicine:', error)
    return NextResponse.json(
      { error: 'Failed to create medicine' },
      { status: 500 }
    )
  }
}