import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all patients
export async function GET() {
  try {
    const patients = await db.patient.findMany({
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            createdAt: true
          }
        },
        _count: {
          select: {
            appointments: true,
            medicalRecords: true,
            bills: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(patients)
  } catch (error) {
    console.error('Error fetching patients:', error)
    return NextResponse.json(
      { error: 'Failed to fetch patients' },
      { status: 500 }
    )
  }
}

// POST new patient
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    // Create user first
    const user = await db.user.create({
      data: {
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: 'PATIENT',
        password: data.password || 'temp123' // In production, hash this password
      }
    })

    // Create patient profile
    const patient = await db.patient.create({
      data: {
        userId: user.id,
        bloodGroup: data.bloodGroup,
        allergies: data.allergies,
        medicalHistory: data.medicalHistory,
        emergencyContact: data.emergencyContact,
        dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth) : null,
        gender: data.gender,
        address: data.address
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            createdAt: true
          }
        }
      }
    })

    return NextResponse.json(patient, { status: 201 })
  } catch (error) {
    console.error('Error creating patient:', error)
    return NextResponse.json(
      { error: 'Failed to create patient' },
      { status: 500 }
    )
  }
}