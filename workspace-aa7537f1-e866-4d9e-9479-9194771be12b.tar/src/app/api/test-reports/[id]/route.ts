import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET single test report
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const testReport = await db.testReport.findUnique({
      where: { id: params.id },
      include: {
        patient: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        test: true
      }
    })

    if (!testReport) {
      return NextResponse.json(
        { error: 'Test report not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(testReport)
  } catch (error) {
    console.error('Error fetching test report:', error)
    return NextResponse.json(
      { error: 'Failed to fetch test report' },
      { status: 500 }
    )
  }
}

// PUT update test report
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json()
    
    const testReport = await db.testReport.update({
      where: { id: params.id },
      data: {
        result: data.result,
        status: data.status,
        notes: data.notes,
        reportUrl: data.reportUrl
      },
      include: {
        patient: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        test: {
          select: {
            name: true,
            price: true,
            category: true
          }
        }
      }
    })

    return NextResponse.json(testReport)
  } catch (error) {
    console.error('Error updating test report:', error)
    return NextResponse.json(
      { error: 'Failed to update test report' },
      { status: 500 }
    )
  }
}

// DELETE test report
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.testReport.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Test report deleted successfully' })
  } catch (error) {
    console.error('Error deleting test report:', error)
    return NextResponse.json(
      { error: 'Failed to delete test report' },
      { status: 500 }
    )
  }
}