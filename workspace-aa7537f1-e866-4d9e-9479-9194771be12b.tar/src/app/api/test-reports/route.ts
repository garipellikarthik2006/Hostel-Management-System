import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all test reports
export async function GET() {
  try {
    const testReports = await db.testReport.findMany({
      include: {
        patient: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        test: {
          select: {
            name: true,
            price: true,
            category: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(testReports)
  } catch (error) {
    console.error('Error fetching test reports:', error)
    return NextResponse.json(
      { error: 'Failed to fetch test reports' },
      { status: 500 }
    )
  }
}

// POST new test report (test request)
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    const testReport = await db.testReport.create({
      data: {
        patientId: data.patientId,
        testId: data.testId,
        result: data.result || 'Pending',
        status: 'PENDING',
        notes: data.notes
      },
      include: {
        patient: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
                phone: true
              }
            }
          }
        },
        test: {
          select: {
            name: true,
            price: true,
            category: true
          }
        }
      }
    })

    return NextResponse.json(testReport, { status: 201 })
  } catch (error) {
    console.error('Error creating test report:', error)
    return NextResponse.json(
      { error: 'Failed to create test report' },
      { status: 500 }
    )
  }
}