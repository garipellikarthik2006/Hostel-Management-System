import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all tests
export async function GET() {
  try {
    const tests = await db.test.findMany({
      include: {
        _count: {
          select: {
            testReports: true
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json(tests)
  } catch (error) {
    console.error('Error fetching tests:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tests' },
      { status: 500 }
    )
  }
}

// POST new test
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    const test = await db.test.create({
      data: {
        name: data.name,
        description: data.description,
        price: parseFloat(data.price),
        category: data.category
      }
    })

    return NextResponse.json(test, { status: 201 })
  } catch (error) {
    console.error('Error creating test:', error)
    return NextResponse.json(
      { error: 'Failed to create test' },
      { status: 500 }
    )
  }
}