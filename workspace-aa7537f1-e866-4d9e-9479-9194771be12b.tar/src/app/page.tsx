'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Users, 
  Calendar, 
  FileText, 
  Pill, 
  TestTube, 
  CreditCard, 
  BarChart3,
  Activity,
  Clock,
  TrendingUp,
  UserPlus,
  Stethoscope,
  Building
} from 'lucide-react'
import PatientManagement from '@/components/PatientManagement'
import DoctorManagement from '@/components/DoctorManagement'
import AppointmentManagement from '@/components/AppointmentManagement'
import LoginRegister from '@/components/LoginRegister'
import LaboratoryManagement from '@/components/LaboratoryManagement'
import PharmacyManagement from '@/components/PharmacyManagement'
import { useAuth } from '@/contexts/AuthContext'

export default function HospitalDashboard() {
  const [activeTab, setActiveTab] = useState('overview')
  const { user, isAuthenticated, isLoading } = useAuth()

  // Determine which tabs to show based on user role
  const getAvailableTabs = () => {
    if (!isAuthenticated || !user) {
      return ['overview']
    }

    const role = user.role
    const tabs = ['overview']

    switch (role) {
      case 'ADMIN':
        tabs.push('patients', 'doctors', 'appointments', 'pharmacy', 'lab')
        break
      case 'DOCTOR':
        tabs.push('patients', 'appointments', 'lab')
        break
      case 'NURSE':
      case 'RECEPTIONIST':
        tabs.push('patients', 'appointments')
        break
      case 'PHARMACIST':
        tabs.push('patients', 'pharmacy')
        break
      case 'LAB_TECHNICIAN':
        tabs.push('lab')
        break
      case 'PATIENT':
        tabs.push('appointments', 'lab')
        break
      default:
        tabs.push('overview')
    }

    return tabs
  }

  const availableTabs = getAvailableTabs()

  // Mock data for demonstration
  const stats = [
    { title: 'Total Patients', value: '1,234', change: '+12%', icon: Users, color: 'text-blue-600' },
    { title: 'Active Doctors', value: '45', change: '+3%', icon: Stethoscope, color: 'text-green-600' },
    { title: 'Today\'s Appointments', value: '89', change: '+8%', icon: Calendar, color: 'text-purple-600' },
    { title: 'Revenue (Month)', value: '$45,678', change: '+15%', icon: CreditCard, color: 'text-orange-600' },
  ]

  const recentAppointments = [
    { id: 1, patient: 'John Doe', doctor: 'Dr. Smith', time: '09:00 AM', status: 'Confirmed' },
    { id: 2, patient: 'Jane Smith', doctor: 'Dr. Johnson', time: '10:30 AM', status: 'Pending' },
    { id: 3, patient: 'Bob Wilson', doctor: 'Dr. Brown', time: '02:00 PM', status: 'Confirmed' },
    { id: 4, patient: 'Alice Davis', doctor: 'Dr. Smith', time: '03:30 PM', status: 'Cancelled' },
  ]

  const lowStockMedicines = [
    { name: 'Paracetamol', stock: 15, minStock: 50 },
    { name: 'Amoxicillin', stock: 8, minStock: 30 },
    { name: 'Ibuprofen', stock: 22, minStock: 40 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Building className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">VN Hospital</h1>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm">
                <Clock className="h-4 w-4 mr-2" />
                {new Date().toLocaleDateString()}
              </Button>
              <LoginRegister />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className={`grid w-full grid-cols-${availableTabs.length}`}>
            {availableTabs.includes('overview') && (
              <TabsTrigger value="overview">Overview</TabsTrigger>
            )}
            {availableTabs.includes('patients') && (
              <TabsTrigger value="patients">Patients</TabsTrigger>
            )}
            {availableTabs.includes('doctors') && (
              <TabsTrigger value="doctors">Doctors</TabsTrigger>
            )}
            {availableTabs.includes('appointments') && (
              <TabsTrigger value="appointments">Appointments</TabsTrigger>
            )}
            {availableTabs.includes('pharmacy') && (
              <TabsTrigger value="pharmacy">Pharmacy</TabsTrigger>
            )}
            {availableTabs.includes('lab') && (
              <TabsTrigger value="lab">Laboratory</TabsTrigger>
            )}
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                    <stat.icon className={`h-4 w-4 ${stat.color}`} />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <p className="text-xs text-green-600 flex items-center">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {stat.change} from last month
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Appointments</CardTitle>
                  <CardDescription>Today's scheduled appointments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{appointment.patient}</p>
                          <p className="text-sm text-gray-500">{appointment.doctor} • {appointment.time}</p>
                        </div>
                        <Badge variant={appointment.status === 'Confirmed' ? 'default' : 
                                      appointment.status === 'Pending' ? 'secondary' : 'destructive'}>
                          {appointment.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Low Stock Alert</CardTitle>
                  <CardDescription>Medicines that need restocking</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {lowStockMedicines.map((medicine, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{medicine.name}</p>
                          <p className="text-sm text-gray-500">Min: {medicine.minStock}</p>
                        </div>
                        <Badge variant="destructive">
                          Stock: {medicine.stock}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Patients Tab */}
          {availableTabs.includes('patients') && (
            <TabsContent value="patients">
              <PatientManagement />
            </TabsContent>
          )}

          {/* Doctors Tab */}
          {availableTabs.includes('doctors') && (
            <TabsContent value="doctors">
              <DoctorManagement />
            </TabsContent>
          )}

          {/* Appointments Tab */}
          {availableTabs.includes('appointments') && (
            <TabsContent value="appointments">
              <AppointmentManagement />
            </TabsContent>
          )}

          {/* Pharmacy Tab */}
          {availableTabs.includes('pharmacy') && (
            <TabsContent value="pharmacy">
              <PharmacyManagement />
            </TabsContent>
          )}

          {/* Laboratory Tab */}
          {availableTabs.includes('lab') && (
            <TabsContent value="lab">
              <LaboratoryManagement />
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  )
}