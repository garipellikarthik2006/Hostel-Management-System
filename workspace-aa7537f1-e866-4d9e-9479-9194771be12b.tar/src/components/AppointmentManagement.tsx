'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  Calendar, 
  Search, 
  Plus, 
  Eye, 
  Edit, 
  Trash2,
  Clock,
  User,
  Stethoscope,
  FileText,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react'

interface Appointment {
  id: string
  patientId: string
  doctorId: string
  userId: string
  date: string
  time: string
  status: 'SCHEDULED' | 'CONFIRMED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW'
  reason?: string
  notes?: string
  createdAt: string
  updatedAt: string
  patient: {
    id: string
    user: {
      name: string
      email: string
      phone?: string
    }
  }
  doctor: {
    id: string
    user: {
      name: string
      email: string
      phone?: string
    }
  }
}

interface Patient {
  id: string
  user: {
    name: string
    email: string
  }
}

interface Doctor {
  id: string
  user: {
    name: string
    email: string
  }
  specialization: string
}

export default function AppointmentManagement() {
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)

  // Form state for adding appointment
  const [formData, setFormData] = useState({
    patientId: '',
    doctorId: '',
    userId: 'temp-user-id', // In production, this would be the logged-in user
    date: '',
    time: '',
    reason: '',
    notes: ''
  })

  const timeSlots = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM', '05:00 PM'
  ]

  const statusColors = {
    SCHEDULED: 'bg-blue-100 text-blue-800',
    CONFIRMED: 'bg-green-100 text-green-800',
    IN_PROGRESS: 'bg-yellow-100 text-yellow-800',
    COMPLETED: 'bg-gray-100 text-gray-800',
    CANCELLED: 'bg-red-100 text-red-800',
    NO_SHOW: 'bg-orange-100 text-orange-800'
  }

  useEffect(() => {
    fetchAppointments()
    fetchPatients()
    fetchDoctors()
  }, [])

  const fetchAppointments = async () => {
    try {
      const response = await fetch('/api/appointments')
      if (response.ok) {
        const data = await response.json()
        setAppointments(data)
      }
    } catch (error) {
      console.error('Error fetching appointments:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchPatients = async () => {
    try {
      const response = await fetch('/api/patients')
      if (response.ok) {
        const data = await response.json()
        setPatients(data)
      }
    } catch (error) {
      console.error('Error fetching patients:', error)
    }
  }

  const fetchDoctors = async () => {
    try {
      const response = await fetch('/api/doctors')
      if (response.ok) {
        const data = await response.json()
        setDoctors(data)
      }
    } catch (error) {
      console.error('Error fetching doctors:', error)
    }
  }

  const handleAddAppointment = async () => {
    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        await fetchAppointments()
        setIsAddDialogOpen(false)
        setFormData({
          patientId: '',
          doctorId: '',
          userId: 'temp-user-id',
          date: '',
          time: '',
          reason: '',
          notes: ''
        })
      }
    } catch (error) {
      console.error('Error adding appointment:', error)
    }
  }

  const handleUpdateStatus = async (appointmentId: string, status: string) => {
    try {
      const response = await fetch(`/api/appointments/${appointmentId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      })

      if (response.ok) {
        await fetchAppointments()
      }
    } catch (error) {
      console.error('Error updating appointment status:', error)
    }
  }

  const filteredAppointments = appointments.filter(appointment =>
    appointment.patient.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    appointment.doctor.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    appointment.status.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const todayAppointments = filteredAppointments.filter(
    appointment => new Date(appointment.date).toDateString() === new Date().toDateString()
  )

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading appointments...</div>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Appointment Scheduling</h2>
          <p className="text-gray-500">Manage patient appointments and schedules</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Appointment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Schedule New Appointment</DialogTitle>
              <DialogDescription>
                Book an appointment for a patient with a doctor.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="patientId">Patient</Label>
                <Select value={formData.patientId} onValueChange={(value) => setFormData({ ...formData, patientId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.user.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="doctorId">Doctor</Label>
                <Select value={formData.doctorId} onValueChange={(value) => setFormData({ ...formData, doctorId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select doctor" />
                  </SelectTrigger>
                  <SelectContent>
                    {doctors.map((doctor) => (
                      <SelectItem key={doctor.id} value={doctor.id}>
                        Dr. {doctor.user.name} - {doctor.specialization}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
              <div>
                <Label htmlFor="time">Time</Label>
                <Select value={formData.time} onValueChange={(value) => setFormData({ ...formData, time: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label htmlFor="reason">Reason for Visit</Label>
                <Input
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="Reason for appointment"
                />
              </div>
              <div className="col-span-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Additional notes"
                  rows={3}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddAppointment}>
                Schedule Appointment
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search appointments..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Today's Appointments */}
      <Card>
        <CardHeader>
          <CardTitle>Today's Schedule</CardTitle>
          <CardDescription>{new Date().toLocaleDateString()}</CardDescription>
        </CardHeader>
        <CardContent>
          {todayAppointments.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No appointments scheduled for today</p>
          ) : (
            <div className="space-y-4">
              {todayAppointments.map((appointment) => (
                <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <Clock className="h-5 w-5 text-gray-400 mx-auto mb-1" />
                      <p className="font-medium">{appointment.time}</p>
                    </div>
                    <div>
                      <p className="font-medium">{appointment.patient.user.name}</p>
                      <p className="text-sm text-gray-500">Dr. {appointment.doctor.user.name}</p>
                      {appointment.reason && (
                        <p className="text-sm text-gray-400">{appointment.reason}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={statusColors[appointment.status]}>
                      {appointment.status}
                    </Badge>
                    <div className="flex gap-1">
                      {appointment.status === 'SCHEDULED' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUpdateStatus(appointment.id, 'CONFIRMED')}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                      {appointment.status === 'CONFIRMED' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUpdateStatus(appointment.id, 'IN_PROGRESS')}
                        >
                          <Clock className="h-4 w-4" />
                        </Button>
                      )}
                      {appointment.status === 'IN_PROGRESS' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUpdateStatus(appointment.id, 'COMPLETED')}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUpdateStatus(appointment.id, 'CANCELLED')}
                      >
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* All Appointments */}
      <Card>
        <CardHeader>
          <CardTitle>All Appointments</CardTitle>
          <CardDescription>Complete appointment history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredAppointments.map((appointment) => (
              <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <Calendar className="h-5 w-5 text-gray-400 mx-auto mb-1" />
                    <p className="text-sm font-medium">
                      {new Date(appointment.date).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-500">{appointment.time}</p>
                  </div>
                  <div>
                    <p className="font-medium">{appointment.patient.user.name}</p>
                    <p className="text-sm text-gray-500">Dr. {appointment.doctor.user.name}</p>
                    {appointment.reason && (
                      <p className="text-sm text-gray-400">{appointment.reason}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={statusColors[appointment.status]}>
                    {appointment.status}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedAppointment(appointment)
                      setIsViewDialogOpen(true)
                    }}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* View Appointment Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Appointment Details</DialogTitle>
            <DialogDescription>
              Complete appointment information
            </DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-6">
              {/* Basic Information */}
              <div>
                <h3 className="font-semibold mb-3">Appointment Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Patient</Label>
                    <p className="font-medium">{selectedAppointment.patient.user.name}</p>
                    <p className="text-sm text-gray-500">{selectedAppointment.patient.user.email}</p>
                    {selectedAppointment.patient.user.phone && (
                      <p className="text-sm text-gray-500">{selectedAppointment.patient.user.phone}</p>
                    )}
                  </div>
                  <div>
                    <Label>Doctor</Label>
                    <p className="font-medium">Dr. {selectedAppointment.doctor.user.name}</p>
                    <p className="text-sm text-gray-500">{selectedAppointment.doctor.user.email}</p>
                    {selectedAppointment.doctor.user.phone && (
                      <p className="text-sm text-gray-500">{selectedAppointment.doctor.user.phone}</p>
                    )}
                  </div>
                  <div>
                    <Label>Date & Time</Label>
                    <p className="font-medium">
                      {new Date(selectedAppointment.date).toLocaleDateString()} at {selectedAppointment.time}
                    </p>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Badge className={statusColors[selectedAppointment.status]}>
                      {selectedAppointment.status}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Appointment Details */}
              <div>
                <h3 className="font-semibold mb-3">Details</h3>
                <div className="space-y-3">
                  <div>
                    <Label>Reason for Visit</Label>
                    <p className="font-medium">{selectedAppointment.reason || 'Not specified'}</p>
                  </div>
                  <div>
                    <Label>Notes</Label>
                    <p className="font-medium">{selectedAppointment.notes || 'No notes'}</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                {selectedAppointment.status === 'SCHEDULED' && (
                  <Button onClick={() => handleUpdateStatus(selectedAppointment.id, 'CONFIRMED')}>
                    Confirm Appointment
                  </Button>
                )}
                {selectedAppointment.status === 'CONFIRMED' && (
                  <Button onClick={() => handleUpdateStatus(selectedAppointment.id, 'IN_PROGRESS')}>
                    Start Consultation
                  </Button>
                )}
                {selectedAppointment.status === 'IN_PROGRESS' && (
                  <Button onClick={() => handleUpdateStatus(selectedAppointment.id, 'COMPLETED')}>
                    Complete Appointment
                  </Button>
                )}
                {(selectedAppointment.status === 'SCHEDULED' || selectedAppointment.status === 'CONFIRMED') && (
                  <Button
                    variant="destructive"
                    onClick={() => handleUpdateStatus(selectedAppointment.id, 'CANCELLED')}
                  >
                    Cancel Appointment
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}