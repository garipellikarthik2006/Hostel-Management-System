'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  TestTube, 
  Search, 
  Plus, 
  Eye, 
  Edit, 
  Trash2,
  FileText,
  User,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  DollarSign
} from 'lucide-react'

interface Test {
  id: string
  name: string
  description?: string
  price: number
  category?: string
  createdAt: string
  updatedAt: string
  _count: {
    testReports: number
  }
}

interface TestReport {
  id: string
  patientId: string
  testId: string
  result: string
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  notes?: string
  reportUrl?: string
  createdAt: string
  updatedAt: string
  patient: {
    id: string
    user: {
      name: string
      email: string
      phone?: string
    }
  }
  test: {
    id: string
    name: string
    price: number
    category?: string
  }
}

interface Patient {
  id: string
  user: {
    name: string
    email: string
  }
}

export default function LaboratoryManagement() {
  const [testReports, setTestReports] = useState<TestReport[]>([])
  const [tests, setTests] = useState<Test[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [isTestRequestDialogOpen, setIsTestRequestDialogOpen] = useState(false)
  const [selectedTestReport, setSelectedTestReport] = useState<TestReport | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)

  // Form state for new test request
  const [testRequestData, setTestRequestData] = useState({
    patientId: '',
    testId: '',
    notes: ''
  })

  const statusColors = {
    PENDING: 'bg-yellow-100 text-yellow-800',
    IN_PROGRESS: 'bg-blue-100 text-blue-800',
    COMPLETED: 'bg-green-100 text-green-800',
    CANCELLED: 'bg-red-100 text-red-800'
  }

  useEffect(() => {
    fetchTestReports()
    fetchTests()
    fetchPatients()
  }, [])

  const fetchTestReports = async () => {
    try {
      const response = await fetch('/api/test-reports')
      if (response.ok) {
        const data = await response.json()
        setTestReports(data)
      }
    } catch (error) {
      console.error('Error fetching test reports:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchTests = async () => {
    try {
      const response = await fetch('/api/tests')
      if (response.ok) {
        const data = await response.json()
        setTests(data)
      }
    } catch (error) {
      console.error('Error fetching tests:', error)
    }
  }

  const fetchPatients = async () => {
    try {
      const response = await fetch('/api/patients')
      if (response.ok) {
        const data = await response.json()
        setPatients(data)
      }
    } catch (error) {
      console.error('Error fetching patients:', error)
    }
  }

  const handleCreateTestRequest = async () => {
    try {
      const response = await fetch('/api/test-reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testRequestData),
      })

      if (response.ok) {
        await fetchTestReports()
        setIsTestRequestDialogOpen(false)
        setTestRequestData({
          patientId: '',
          testId: '',
          notes: ''
        })
      }
    } catch (error) {
      console.error('Error creating test request:', error)
    }
  }

  const handleUpdateStatus = async (testReportId: string, status: string, result?: string) => {
    try {
      const response = await fetch(`/api/test-reports/${testReportId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          status,
          result: result || 'Processing...'
        }),
      })

      if (response.ok) {
        await fetchTestReports()
      }
    } catch (error) {
      console.error('Error updating test report status:', error)
    }
  }

  const filteredTestReports = testReports.filter(testReport =>
    testReport.patient.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    testReport.test.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    testReport.status.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const pendingTestReports = filteredTestReports.filter(report => report.status === 'PENDING')
  const inProgressTestReports = filteredTestReports.filter(report => report.status === 'IN_PROGRESS')
  const completedTestReports = filteredTestReports.filter(report => report.status === 'COMPLETED')

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading laboratory data...</div>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Laboratory Management</h2>
          <p className="text-gray-500">Manage test requests and results</p>
        </div>
        <Dialog open={isTestRequestDialogOpen} onOpenChange={setIsTestRequestDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <TestTube className="h-4 w-4 mr-2" />
              New Test Request
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>New Test Request</DialogTitle>
              <DialogDescription>
                Create a new test request for a patient.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="patientId">Patient</Label>
                <Select value={testRequestData.patientId} onValueChange={(value) => setTestRequestData({ ...testRequestData, patientId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.user.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="testId">Test</Label>
                <Select value={testRequestData.testId} onValueChange={(value) => setTestRequestData({ ...testRequestData, testId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select test" />
                  </SelectTrigger>
                  <SelectContent>
                    {tests.map((test) => (
                      <SelectItem key={test.id} value={test.id}>
                        {test.name} - ${test.price}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={testRequestData.notes}
                  onChange={(e) => setTestRequestData({ ...testRequestData, notes: e.target.value })}
                  placeholder="Additional notes for the test"
                  rows={3}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsTestRequestDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateTestRequest}>
                  Create Test Request
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search test reports..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Tests</CardTitle>
            <AlertCircle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingTestReports.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Clock className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inProgressTestReports.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedTestReports.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Tests</CardTitle>
            <TestTube className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tests.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Test Reports Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Test Results */}
        <Card>
          <CardHeader>
            <CardTitle>Pending Test Results</CardTitle>
            <CardDescription>Tests awaiting processing</CardDescription>
          </CardHeader>
          <CardContent>
            {pendingTestReports.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No pending tests</p>
            ) : (
              <div className="space-y-4">
                {pendingTestReports.map((testReport) => (
                  <div key={testReport.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">{testReport.patient.user.name}</p>
                      <p className="text-sm text-gray-500">{testReport.test.name}</p>
                      <p className="text-xs text-gray-400">
                        {new Date(testReport.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={statusColors[testReport.status]}>
                        {testReport.status}
                      </Badge>
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUpdateStatus(testReport.id, 'IN_PROGRESS')}
                        >
                          <Clock className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedTestReport(testReport)
                            setIsViewDialogOpen(true)
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Available Tests */}
        <Card>
          <CardHeader>
            <CardTitle>Available Tests</CardTitle>
            <CardDescription>Tests that can be requested</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {tests.map((test) => (
                <div key={test.id} className="flex justify-between items-center p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{test.name}</p>
                    <p className="text-sm text-gray-500">{test.category || 'General'}</p>
                    <p className="text-xs text-gray-400">{test._count.testReports} requests</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-green-600">${test.price}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* All Test Reports */}
      <Card>
        <CardHeader>
          <CardTitle>All Test Reports</CardTitle>
          <CardDescription>Complete test report history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredTestReports.map((testReport) => (
              <div key={testReport.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <TestTube className="h-5 w-5 text-gray-400 mx-auto mb-1" />
                    <p className="text-sm font-medium">{testReport.test.name}</p>
                  </div>
                  <div>
                    <p className="font-medium">{testReport.patient.user.name}</p>
                    <p className="text-sm text-gray-500">{testReport.patient.user.email}</p>
                    <p className="text-xs text-gray-400">
                      Requested: {new Date(testReport.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={statusColors[testReport.status]}>
                    {testReport.status}
                  </Badge>
                  <div className="flex gap-1">
                    {testReport.status === 'PENDING' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUpdateStatus(testReport.id, 'IN_PROGRESS')}
                      >
                        <Clock className="h-4 w-4" />
                      </Button>
                    )}
                    {testReport.status === 'IN_PROGRESS' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUpdateStatus(testReport.id, 'COMPLETED', 'Test completed successfully')}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedTestReport(testReport)
                        setIsViewDialogOpen(true)
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* View Test Report Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Test Report Details</DialogTitle>
            <DialogDescription>
              Complete test report information
            </DialogDescription>
          </DialogHeader>
          {selectedTestReport && (
            <div className="space-y-6">
              {/* Basic Information */}
              <div>
                <h3 className="font-semibold mb-3">Test Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Patient</Label>
                    <p className="font-medium">{selectedTestReport.patient.user.name}</p>
                    <p className="text-sm text-gray-500">{selectedTestReport.patient.user.email}</p>
                    {selectedTestReport.patient.user.phone && (
                      <p className="text-sm text-gray-500">{selectedTestReport.patient.user.phone}</p>
                    )}
                  </div>
                  <div>
                    <Label>Test</Label>
                    <p className="font-medium">{selectedTestReport.test.name}</p>
                    <p className="text-sm text-gray-500">{selectedTestReport.test.category || 'General'}</p>
                    <p className="text-sm text-gray-500">${selectedTestReport.test.price}</p>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Badge className={statusColors[selectedTestReport.status]}>
                      {selectedTestReport.status}
                    </Badge>
                  </div>
                  <div>
                    <Label>Requested Date</Label>
                    <p className="font-medium">
                      {new Date(selectedTestReport.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>

              {/* Test Details */}
              <div>
                <h3 className="font-semibold mb-3">Test Details</h3>
                <div className="space-y-3">
                  <div>
                    <Label>Result</Label>
                    <p className="font-medium">{selectedTestReport.result || 'Pending'}</p>
                  </div>
                  <div>
                    <Label>Notes</Label>
                    <p className="font-medium">{selectedTestReport.notes || 'No notes'}</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                {selectedTestReport.status === 'PENDING' && (
                  <Button onClick={() => handleUpdateStatus(selectedTestReport.id, 'IN_PROGRESS')}>
                    Start Processing
                  </Button>
                )}
                {selectedTestReport.status === 'IN_PROGRESS' && (
                  <Button onClick={() => handleUpdateStatus(selectedTestReport.id, 'COMPLETED', 'Test completed successfully')}>
                    Mark as Completed
                  </Button>
                )}
                {(selectedTestReport.status === 'PENDING' || selectedTestReport.status === 'IN_PROGRESS') && (
                  <Button
                    variant="destructive"
                    onClick={() => handleUpdateStatus(selectedTestReport.id, 'CANCELLED')}
                  >
                    Cancel Test
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}