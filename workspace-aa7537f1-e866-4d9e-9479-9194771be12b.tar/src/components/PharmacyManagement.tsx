'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Pill, 
  Search, 
  Plus, 
  Eye, 
  Edit, 
  Trash2,
  Package,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Calendar,
  DollarSign,
  FileText,
  ShoppingCart,
  Clock,
  CheckCircle
} from 'lucide-react'

interface Medicine {
  id: string
  name: string
  description?: string
  category: string
  price: number
  stock: number
  minStock: number
  expiryDate?: string
  manufacturer?: string
  createdAt: string
  updatedAt: string
  _count: {
    billItems: number
    inventoryLogs: number
  }
}

interface InventoryLog {
  id: string
  medicineId: string
  type: string
  quantity: number
  reason?: string
  createdAt: string
  medicine: {
    name: string
    category: string
  }
}

interface Prescription {
  id: string
  medicalRecordId: string
  medicineName: string
  dosage: string
  frequency: string
  duration: string
  instructions?: string
  createdAt: string
  medicalRecord: {
    patient: {
      user: {
        name: string
        email: string
        phone?: string
      }
    }
    doctor: {
      user: {
        name: string
      }
    }
  }
}

export default function PharmacyManagement() {
  const [medicines, setMedicines] = useState<Medicine[]>([])
  const [inventoryLogs, setInventoryLogs] = useState<InventoryLog[]>([])
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [activeTab, setActiveTab] = useState('medicines')
  
  // Dialog states
  const [isAddMedicineDialogOpen, setIsAddMedicineDialogOpen] = useState(false)
  const [isInventoryDialogOpen, setIsInventoryDialogOpen] = useState(false)
  const [isViewMedicineDialogOpen, setIsViewMedicineDialogOpen] = useState(false)
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null)

  // Form states
  const [medicineFormData, setMedicineFormData] = useState({
    name: '',
    description: '',
    category: '',
    price: '',
    stock: '',
    minStock: '',
    expiryDate: '',
    manufacturer: ''
  })

  const [inventoryFormData, setInventoryFormData] = useState({
    medicineId: '',
    type: 'IN',
    quantity: '',
    reason: ''
  })

  useEffect(() => {
    fetchMedicines()
    fetchInventoryLogs()
    fetchPrescriptions()
  }, [])

  const fetchMedicines = async () => {
    try {
      const response = await fetch('/api/medicines')
      if (response.ok) {
        const data = await response.json()
        setMedicines(data)
      }
    } catch (error) {
      console.error('Error fetching medicines:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchInventoryLogs = async () => {
    try {
      const response = await fetch('/api/inventory')
      if (response.ok) {
        const data = await response.json()
        setInventoryLogs(data)
      }
    } catch (error) {
      console.error('Error fetching inventory logs:', error)
    }
  }

  const fetchPrescriptions = async () => {
    try {
      const response = await fetch('/api/prescriptions')
      if (response.ok) {
        const data = await response.json()
        setPrescriptions(data)
      }
    } catch (error) {
      console.error('Error fetching prescriptions:', error)
    }
  }

  const handleAddMedicine = async () => {
    try {
      const response = await fetch('/api/medicines', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(medicineFormData),
      })

      if (response.ok) {
        await fetchMedicines()
        setIsAddMedicineDialogOpen(false)
        setMedicineFormData({
          name: '',
          description: '',
          category: '',
          price: '',
          stock: '',
          minStock: '',
          expiryDate: '',
          manufacturer: ''
        })
      }
    } catch (error) {
      console.error('Error adding medicine:', error)
    }
  }

  const handleInventoryAdjustment = async () => {
    try {
      const response = await fetch('/api/inventory', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(inventoryFormData),
      })

      if (response.ok) {
        await fetchMedicines()
        await fetchInventoryLogs()
        setIsInventoryDialogOpen(false)
        setInventoryFormData({
          medicineId: '',
          type: 'IN',
          quantity: '',
          reason: ''
        })
      }
    } catch (error) {
      console.error('Error adjusting inventory:', error)
    }
  }

  const getStockStatus = (medicine: Medicine) => {
    if (medicine.stock === 0) return { status: 'Out of Stock', color: 'destructive' }
    if (medicine.stock <= medicine.minStock) return { status: 'Low Stock', color: 'destructive' }
    if (medicine.expiryDate && new Date(medicine.expiryDate) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)) {
      return { status: 'Expiring Soon', color: 'destructive' }
    }
    return { status: 'Available', color: 'default' }
  }

  const filteredMedicines = medicines.filter(medicine =>
    medicine.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    medicine.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    medicine.manufacturer?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const lowStockMedicines = medicines.filter(medicine => medicine.stock <= medicine.minStock)
  const expiringMedicines = medicines.filter(medicine => 
    medicine.expiryDate && new Date(medicine.expiryDate) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  )

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading pharmacy data...</div>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Pharmacy Management</h2>
          <p className="text-gray-500">Manage medicines, inventory, and prescriptions</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isInventoryDialogOpen} onOpenChange={setIsInventoryDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Package className="h-4 w-4 mr-2" />
                Inventory
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Inventory Adjustment</DialogTitle>
                <DialogDescription>
                  Add or remove stock from inventory
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="medicineId">Medicine</Label>
                  <Select value={inventoryFormData.medicineId} onValueChange={(value) => setInventoryFormData({ ...inventoryFormData, medicineId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select medicine" />
                    </SelectTrigger>
                    <SelectContent>
                      {medicines.map((medicine) => (
                        <SelectItem key={medicine.id} value={medicine.id}>
                          {medicine.name} (Stock: {medicine.stock})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select value={inventoryFormData.type} onValueChange={(value) => setInventoryFormData({ ...inventoryFormData, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="IN">Stock In</SelectItem>
                      <SelectItem value="OUT">Stock Out</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={inventoryFormData.quantity}
                    onChange={(e) => setInventoryFormData({ ...inventoryFormData, quantity: e.target.value })}
                    placeholder="Enter quantity"
                  />
                </div>
                <div>
                  <Label htmlFor="reason">Reason</Label>
                  <Input
                    id="reason"
                    value={inventoryFormData.reason}
                    onChange={(e) => setInventoryFormData({ ...inventoryFormData, reason: e.target.value })}
                    placeholder="Reason for adjustment"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsInventoryDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleInventoryAdjustment}>
                    Adjust Stock
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isAddMedicineDialogOpen} onOpenChange={setIsAddMedicineDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Medicine
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Medicine</DialogTitle>
                <DialogDescription>
                  Enter medicine details to add to inventory
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Medicine Name *</Label>
                  <Input
                    id="name"
                    value={medicineFormData.name}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, name: e.target.value })}
                    placeholder="Enter medicine name"
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Input
                    id="category"
                    value={medicineFormData.category}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, category: e.target.value })}
                    placeholder="e.g., Antibiotics, Pain Relief"
                  />
                </div>
                <div>
                  <Label htmlFor="price">Price ($) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={medicineFormData.price}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, price: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <Label htmlFor="stock">Initial Stock *</Label>
                  <Input
                    id="stock"
                    type="number"
                    value={medicineFormData.stock}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, stock: e.target.value })}
                    placeholder="0"
                  />
                </div>
                <div>
                  <Label htmlFor="minStock">Minimum Stock</Label>
                  <Input
                    id="minStock"
                    type="number"
                    value={medicineFormData.minStock}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, minStock: e.target.value })}
                    placeholder="10"
                  />
                </div>
                <div>
                  <Label htmlFor="expiryDate">Expiry Date</Label>
                  <Input
                    id="expiryDate"
                    type="date"
                    value={medicineFormData.expiryDate}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, expiryDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="manufacturer">Manufacturer</Label>
                  <Input
                    id="manufacturer"
                    value={medicineFormData.manufacturer}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, manufacturer: e.target.value })}
                    placeholder="Manufacturer name"
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={medicineFormData.description}
                    onChange={(e) => setMedicineFormData({ ...medicineFormData, description: e.target.value })}
                    placeholder="Medicine description"
                    rows={3}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setIsAddMedicineDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddMedicine}>
                  Add Medicine
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search medicines..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Medicines</CardTitle>
            <Pill className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{medicines.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Alert</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{lowStockMedicines.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{expiringMedicines.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Prescriptions</CardTitle>
            <FileText className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{prescriptions.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="medicines">Medicines</TabsTrigger>
          <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
          <TabsTrigger value="inventory">Inventory Logs</TabsTrigger>
        </TabsList>

        {/* Medicines Tab */}
        <TabsContent value="medicines" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Medicine Inventory</CardTitle>
              <CardDescription>Manage medicine stock and availability</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredMedicines.map((medicine) => {
                  const stockStatus = getStockStatus(medicine)
                  return (
                    <div key={medicine.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <Pill className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium">{medicine.name}</p>
                          <p className="text-sm text-gray-500">{medicine.category}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-sm text-gray-500">Stock: {medicine.stock}</span>
                            <span className="text-sm text-gray-500">Min: {medicine.minStock}</span>
                            {medicine.expiryDate && (
                              <span className="text-sm text-gray-500">
                                Expires: {new Date(medicine.expiryDate).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={stockStatus.color as any}>
                          {stockStatus.status}
                        </Badge>
                        <span className="font-bold text-green-600">${medicine.price}</span>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedMedicine(medicine)
                              setIsViewMedicineDialogOpen(true)
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setInventoryFormData({ ...inventoryFormData, medicineId: medicine.id })
                              setIsInventoryDialogOpen(true)
                            }}
                          >
                            <Package className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Prescriptions Tab */}
        <TabsContent value="prescriptions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Prescriptions</CardTitle>
              <CardDescription>View and manage patient prescriptions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {prescriptions.map((prescription) => (
                  <div key={prescription.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                        <FileText className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">{prescription.medicineName}</p>
                        <p className="text-sm text-gray-500">
                          Patient: {prescription.medicalRecord.patient.user.name}
                        </p>
                        <p className="text-sm text-gray-500">
                          Doctor: {prescription.medicalRecord.doctor.user.name}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm text-gray-500">{prescription.dosage}</span>
                          <span className="text-sm text-gray-500">•</span>
                          <span className="text-sm text-gray-500">{prescription.frequency}</span>
                          <span className="text-sm text-gray-500">•</span>
                          <span className="text-sm text-gray-500">{prescription.duration}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {new Date(prescription.createdAt).toLocaleDateString()}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <ShoppingCart className="h-4 w-4 mr-1" />
                        Dispense
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Inventory Logs Tab */}
        <TabsContent value="inventory" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Inventory Movement</CardTitle>
              <CardDescription>Track stock changes and adjustments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {inventoryLogs.map((log) => (
                  <div key={log.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                        log.type === 'IN' ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {log.type === 'IN' ? (
                          <TrendingUp className="h-6 w-6 text-green-600" />
                        ) : (
                          <TrendingDown className="h-6 w-6 text-red-600" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{log.medicine.name}</p>
                        <p className="text-sm text-gray-500">{log.reason || 'No reason provided'}</p>
                        <p className="text-xs text-gray-400">
                          {new Date(log.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={log.type === 'IN' ? 'default' : 'destructive'}>
                        {log.type === 'IN' ? '+' : '-'}{log.quantity}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* View Medicine Dialog */}
      <Dialog open={isViewMedicineDialogOpen} onOpenChange={setIsViewMedicineDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Medicine Details</DialogTitle>
            <DialogDescription>
              Complete medicine information and history
            </DialogDescription>
          </DialogHeader>
          {selectedMedicine && (
            <div className="space-y-6">
              {/* Basic Information */}
              <div>
                <h3 className="font-semibold mb-3">Basic Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Medicine Name</Label>
                    <p className="font-medium">{selectedMedicine.name}</p>
                  </div>
                  <div>
                    <Label>Category</Label>
                    <p className="font-medium">{selectedMedicine.category}</p>
                  </div>
                  <div>
                    <Label>Price</Label>
                    <p className="font-medium">${selectedMedicine.price}</p>
                  </div>
                  <div>
                    <Label>Manufacturer</Label>
                    <p className="font-medium">{selectedMedicine.manufacturer || 'N/A'}</p>
                  </div>
                </div>
              </div>

              {/* Stock Information */}
              <div>
                <h3 className="font-semibold mb-3">Stock Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Current Stock</Label>
                    <p className="font-medium">{selectedMedicine.stock}</p>
                  </div>
                  <div>
                    <Label>Minimum Stock</Label>
                    <p className="font-medium">{selectedMedicine.minStock}</p>
                  </div>
                  <div>
                    <Label>Expiry Date</Label>
                    <p className="font-medium">
                      {selectedMedicine.expiryDate 
                        ? new Date(selectedMedicine.expiryDate).toLocaleDateString()
                        : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Badge variant={getStockStatus(selectedMedicine).color as any}>
                      {getStockStatus(selectedMedicine).status}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Statistics */}
              <div>
                <h3 className="font-semibold mb-3">Statistics</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <ShoppingCart className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                      <p className="font-bold text-lg">{selectedMedicine._count.billItems}</p>
                      <p className="text-sm text-gray-500">Times Sold</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <Package className="h-8 w-8 mx-auto mb-2 text-green-600" />
                      <p className="font-bold text-lg">{selectedMedicine._count.inventoryLogs}</p>
                      <p className="text-sm text-gray-500">Stock Changes</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Description */}
              {selectedMedicine.description && (
                <div>
                  <h3 className="font-semibold mb-3">Description</h3>
                  <p className="font-medium">{selectedMedicine.description}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}